Hello everyone, 

I hope you have a good day. This is a framework for 3D and 2D demonstration.

The framework is mainly based on PyQt5 and Pyvista. 

I would like to add more functions here to make it more helpful to you.

The plan is described below:

1. A 3D demo widget with a model tree to set the visibility of features for the models

2. A 2D combo widget for knitting map demonstration.

3. A tool to fully automatically generate the scene for the blender.

4. A robot simulation and real-time controller

5. A library to govern the topology of different geometries.

6. ...
Please let me know if you have any suggestions, hopefully, we can make a earth-shake framework!
